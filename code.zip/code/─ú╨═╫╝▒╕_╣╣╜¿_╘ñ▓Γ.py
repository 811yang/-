import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import random
import math
import operator

plt.rcParams['font.sans-serif'] = ['SimHei']

# 读取数据

# 查看数据

meal_order_detail = pd.read_csv("C:/Users/lenovo/Desktop/智能餐饮推荐服务项目/result/data/clearn_data.csv",encoding = 'utf-8',engine = 'python')
# 属性规约

p_data = meal_order_detail[['emp_id', 'dishes_name']]
shuffle_index = p_data['emp_id'].unique()
random.shuffle(shuffle_index)

# 拆分训练集和测试集，分别为训练集为80%(746),测试集为20%(187)
shuffle_index_train = shuffle_index[:375]
shuffle_index_test = shuffle_index[375:]


# 定义拆分函数，并且先将其按照订单号打乱（同样的订单号，不会被拆分，只拆分不同的订单号）
def train_test_split(orgin_data, data_shuffle):
    df = pd.DataFrame()
    for i in range(len(data_shuffle)):
        dt = orgin_data.loc[orgin_data['emp_id'] == data_shuffle[i], :]
        df = df.append(dt, ignore_index=True)
    return df


# 测试数据 训练数据

train_data = train_test_split(p_data, shuffle_index_train)
test_data = train_test_split(p_data, shuffle_index_test)

# 二元矩阵列名
name_dishes = p_data['dishes_name'].unique()

# 创建字典，每一个用户的，菜品列表
train_data_index = train_data['emp_id'].unique()
dict_metrix = {}
for j in train_data_index:
    list_ = []
    for i in range(len(train_data)):
        if train_data['emp_id'][i] == j:
            dict_metrix[j] = list_.append(train_data.iloc[i]['dishes_name'])
            dict_metrix[j] = list_

        # 删除用户订单 少于三个的用户
for i in list(dict_metrix.keys()):
    if len(dict_metrix[i]) < 3:
        dict_metrix.pop(i)
        train_data.drop(i, inplace=True)

# 创建二元矩阵
data = np.zeros([len(train_data['emp_id'].unique()), len(name_dishes)])
dish_metricx = pd.DataFrame(data, index=train_data['emp_id'].unique(), columns=name_dishes)

# 修改二元矩阵,并进行存储
br_metrix = 'C:/Users/lenovo/Desktop/智能餐饮推荐服务项目/result/data/rb_metrix_data.csv'
for i in list(dict_metrix.keys()):
    for j in dish_metricx.index:
        if i == j:
            for value in dict_metrix[i]:
                for name in dish_metricx.columns:
                    if value == name:
                        dish_metricx.loc[j, value] = 1
dish_metricx.to_csv(br_metrix)


# 测试集二元矩阵

# 二元矩阵列名
name_dishes_test = p_data['dishes_name'].unique()

# 创建字典，每一个用户的，菜品列表
test_data_index = test_data['emp_id'].unique()
dict_metrix_test = {}
for j in test_data_index:
    list_ = []
    for i in range(len(test_data)):
        if test_data['emp_id'][i] == j:
            dict_metrix_test[j] = list_.append(test_data.iloc[i]['dishes_name'])
            dict_metrix_test[j] = list_

        # 删除用户订单 少于三个的用户
for i in list(dict_metrix_test.keys()):
    if len(dict_metrix_test[i]) < 3:
        dict_metrix_test.pop(i)
        test_data.drop(i, inplace=True)

# 创建二元矩阵
data = np.zeros([len(test_data['emp_id'].unique()), len(name_dishes_test)])
dish_metricx_test = pd.DataFrame(data, index=test_data['emp_id'].unique(), columns=name_dishes_test)

# 修改二元矩阵,并进行存储
br_metrix = 'C:/Users/lenovo/Desktop/智能餐饮推荐服务项目/result/data/rb_metrix_data.csv'
for i in list(dict_metrix_test.keys()):
    for j in dish_metricx_test.index:
        if i == j:
            for value in dict_metrix_test[i]:
                for name in dish_metricx_test.columns:
                    if value == name:
                        dish_metricx_test.loc[j, value] = 1
dish_metricx_test.to_csv(br_metrix)



# 菜品相似度计算
def item_similarity(userSet):
    C = dict()
    N = dict()
    for u, items in userSet.items():
        for i in items:
            N.setdefault(i, 0)
            N[i] += 1
            for j in items:
                if i == j:
                    continue
                C.setdefault(i, {})
                C[i].setdefault(j, 0)
                C[i][j] += 1
    print("稀疏矩阵: ", C)
    W = dict()
    for i,related_items in C.items():
        for j, cij in related_items.items():
            W.setdefault(i, {})
            W[i].setdefault(j, 0)
            W[i][j] = cij / math.sqrt(N[i] * N[j])
    return W
    print("物品相似度: ", W)
# 得到相似矩阵字典
W = item_similarity(dict_metrix)

# 将相似矩阵字典转化为dataframe
simi_metrix = pd.DataFrame(W)
simi_metrix.dropna(0)

# 推荐菜品
def recommend_dish_(user_id, data, W, K):
    num = 1
    rank_dish = dict()
    interacted_items = data[user_id]
    set_ = set()
    for user in interacted_items:
        print(">>>>>>>>", user)
        related_item = []
        for user, score in W[user].items():
            related_item.append((user, score))

        for j, v in sorted(related_item, key=operator.itemgetter(1), reverse=True)[:K]:
            print(j, v)
            set_.add(j)
            if j in interacted_items:
                continue
            if j not in rank_dish.keys():
                rank_dish[j]=0
                rank_dish[j] += num * v

    print("推荐菜品: ", rank_dish)
    return rank_dish,set_
test_2,set_ = recommend_dish_(list(dict_metrix_test.keys())[0],dict_metrix_test,W,3)

# 模型评价准确率
def accuracy(set,data_test):
    s = 0
    for i in set_:
        if i in data_test[list(data_test.keys())[0]]:
            s += 1
    rate_accuracy = s/len(data_test[list(data_test.keys())[0]])
    print('准确率：%.1f%%' % (rate_accuracy*100))
    
accuracy(set_,dict_metrix_test)


