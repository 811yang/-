#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import random
plt.rcParams['font.sans-serif'] = ['SimHei']


# In[2]:


meal_order_detail = pd.read_csv("C:/Users/lenovo/Desktop/智能餐饮推荐服务项目/origin_data/meal_order_detail.csv",engine='python')
meal_order_info = pd.read_csv("C:/Users/lenovo/Desktop/智能餐饮推荐服务项目/origin_data/meal_order_info.csv",engine='python')


# In[3]:


meal_order_detail.head()


# In[4]:


dishes_cha = pd.pivot_table(meal_order_detail,values=['counts'],index=['dishes_name'],aggfunc='sum')
dishes_cha.sort_values(by = 'counts',ascending = False).head()


# In[5]:


meal_order_info['order_status'].value_counts() # 有数据可以知道，0,2是没有完成订单的，考虑到所占的比列非常少，因此可以删除掉。


# In[6]:


# # 将白饭/小碗，白饭/大碗 也从订单详情表中删去
meal_order_detail = meal_order_detail.loc[(meal_order_detail['dishes_name'] != "白饭/小碗"),]
meal_order_detail = meal_order_detail.loc[(meal_order_detail['dishes_name'] != "白饭/大碗"),]
print(len(meal_order_detail))

error_id = meal_order_info.loc[(meal_order_info['order_status'] == 0) | (meal_order_info['order_status'] == 2),:]['info_id']
#标记出订单状态的为0 和 2的订单号，并将其删去
for i in error_id:
    meal_order_detail = meal_order_detail.loc[meal_order_detail['order_id'] != i,:]
print(len(meal_order_detail))
meal_order_detail = meal_order_detail.reset_index(drop=True)
clearn_data = "C:/Users/lenovo/Desktop/智能餐饮推荐服务项目/result/data/clearn_data.csv"

# 处理菜品名称中的字符1

list_dish = []
for i in meal_order_detail.index:
    list_dish.append(meal_order_detail['dishes_name'][i].replace('\n\n\n','').replace("\r","").replace("\n",""))
dish_ = pd.Series(list_dish)
meal_order_detail['dishes_name'] = dish_

#保存并输出 处理后的文件
meal_order_detail.to_csv(clearn_data,encoding='utf-8')
meal_order_detail


# In[7]:


order_num = len(meal_order_detail['order_id'].unique())
order_num


# In[8]:


meal_order_detail['cost'] = meal_order_detail['counts'] * meal_order_detail['amounts']
cost_data = meal_order_detail[['order_id','cost']]
cost_data.head()


# In[9]:


def dishes_caculate(df,column1,column2):
    dict_cost = {}
    for i in df[column1].unique():
        sum = 0
        for j,k in enumerate(df[column1]):
            if k == i:
                sum += df[column2][j]
                dict_cost[i] = sum
    return dict_cost


# In[10]:


dict_cost = dishes_caculate(cost_data,column1 = 'order_id',column2 = 'cost')
cost_df = pd.DataFrame(list(dict_cost.values()),columns=['cost'],index=dict_cost.keys())
cost_df.sort_values(by = ['cost'],ascending = False,inplace=True)


# In[11]:


# 单笔消费最高的是
the_high_cost = cost_df[:1]
print('单笔消费最高的是订单号%d,消费为%d：'% (the_high_cost.index[0],the_high_cost['cost']))
print('*' * 50) 
# 费用超过一千的订单
for i,j in enumerate(cost_df['cost']):
      if j < 1000:
            print('费用超过一千的订单共有%d个' % (i-1))
            break
           
print('费用超过一千的订单如下所示：')
order_menu = cost_df[:i]
order_menu[:43]


# In[12]:


# 菜品热销度评分
meal_order_detail.head()
hot_dishes = meal_order_detail[['dishes_name','counts']]
hot_dishes.head()


# In[13]:


hot_dict_dishes = dishes_caculate(hot_dishes,column1 = 'dishes_name',column2 = 'counts')
hot_dishes_df = pd.DataFrame(list(hot_dict_dishes.values()),columns=['counts'],index=hot_dict_dishes.keys())
hot_dishes_df.head()


# In[14]:


# 最大数量菜品是
max_dishes = hot_dishes_df.describe().loc['max']
# 最小数量菜品
min_dishes = hot_dishes_df.describe().loc['min']

# 热销度评分
def hot_score(df,max_dishes,min_dishes):
    return (df - min_dishes)/(max_dishes - min_dishes)

# 热销榜
hot_board_dishes = hot_score(hot_dishes_df,max_dishes,min_dishes)

hot_board_dishes.rename(columns = {'counts':"hot_dishes_score"},inplace=True)
hot_board_dishes.sort_values(by = ['hot_dishes_score'],ascending=False,inplace= True)
hot_board_dishes[:20]


# In[15]:


# 热销度top-10
plt.figure(figsize=(15,15))
hot_board_dishes[:10].plot(kind = 'barh',fontsize = 15,title = '菜品热销度 TOP-10')
fig_file = "C:/Users/lenovo/Desktop/智能餐饮推荐服务项目/result/figure/hot_dishes_score.png"
plt.savefig(fig_file, dpi=600, facecolor='w', edgecolor='w',
          orientation='portrait', papertype=None, format=None,
          transparent=False, bbox_inches='tight', pad_inches=0.1,
          frameon=None)


# In[16]:


# 属性规约
# 属性规约

p_data = meal_order_detail[['emp_id', 'dishes_name']]
p_data

